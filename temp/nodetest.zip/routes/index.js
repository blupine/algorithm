var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/guestboardlist', function(req, res, next){
  res.render('guestboardlist', {title:'Guest Board'});
});

router.get('/newguestmsg', function(req, res, next){
  res.render('newguestmsg', {title:'New guest msg'});
});

router.get('/guestmsglist', function(req, res, next){
    var db = req.db;
    var collection = db.get('guestboard');
    collection.find({}, {}, function(e, docs){
      res.json(docs);
    });

    // collection.find().toArray(function(err, items){
    //   res.json(items);
    // });
});

router.get('/showmsg/:id', function(req, res, next){
  var db = req.db;
  var ObjectId = require('mongodb').ObjectID;
  var collection = db.collection('guestboard');
  collection.find({_id:ObjectId(req.params.id)}, function(err, result){
    if (err) 
      return console.log(err)
    // for(var key in result){
      console.log('key : id' + ', val : ' + result["_id"]);
    
    // }
    res.render('showguestmsg', {guestmsgdata: result})
  });
});



router.post('/saveguestmsg', function(req, res){
  console.log("/saveguestmsg called!!!!!!!!!!");
  var db = req.db;
  var title = req.body.title;
  var writer = req.body.writer;
  var email = req.body.email;
  var contents = req.body.contents;

  var collection = db.collection('guestboard');

  var data = {
    "title":title,
    "writer":writer,
    "email":email,
    "contents":contents
  };
  console.log("data title : " + data.title);

  collection.insert(data, function(err, doc){
    if(err){
      console.log("Insertion failed");

      res.send("There was a problem adding the information to the database.");
    }else{
      console.log("Inserted data ID : " + data._id);
      console.log("doc inserted : " + doc);
      res.render('showguestmsg', data)

      // res.location("showguestmsg");
      // res.redirect("showguestmsg/id?");
    }
  });
});
module.exports = router;
