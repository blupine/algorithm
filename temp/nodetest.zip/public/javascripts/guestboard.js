var guestMsgListData = [];

$(document).ready(function(){
    populateTable();
    // $('#guestBoardList table tbody').on('click', 'td a.linkshowmsg', showGuestMsg);

});

function populateTable(){
    var tableContent = "";
    var index = 1;
    $.getJSON('guestmsglist', function(data){
        $.each(data, function(){
            tableContent += '<tr>';
            tableContent += '<td><a href="showmsg/' + this._id + '" class="linkshowmsg" rel="' + this._id + '">' + index++ + '</a></td>';
            tableContent += '<td>' + this.writer + '</td>';
            tableContent += '<td><a href="#" class="linkshowmsg" rel="' + this.title + '">' + this.title + '</a></td>';
            tableContent += '</tr>';
            
        });
        $('#guestBoardList table tbody').html(tableContent);
    });
;}

function showGuestMsg(event){

};